const app = require('express')()
const http = require('http').createServer(app)
const io = require('socket.io')(http)

const moment = require('moment')


app.get('/', function (req, res) {
  res.sendFile(__dirname + '/index.html')
})
io.on('connection', socket => {
  console.log('连接成功');

  socket.on('cli', msg => {
    msg.time = moment().format('HH:mm:ss')
    console.log('msg: ', msg);
    io.emit('serve', msg)
  })

  socket.on('disconnect', () => {
    io.emit('live')
  })

  socket.to('test', () => {
    console.log('加入房间');
  })
})

var port = process.env.PORT || 3000

http.listen(port, function () {
  var host = http.address().address
  // var port = http.address().port
  console.log('服务已启动, http://%s:%s', host, port);
})